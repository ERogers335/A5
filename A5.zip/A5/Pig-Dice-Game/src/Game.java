import java.util.*;
import java.io.*;

/**
 *
 * This is a project that allows the user to play the classic Pig dice game with a computer as an opponent.
 *
 * @author Evan R.
 * @version 1.23
 *
 *
 */

public class Game {
    private static File file  = new File("pig_game_data.txt");
    static int playerScore = 0;
    static int roundScore = 0;
    private static final int MAX_SCORE = 100;
    private static int computerScore = 0;

    public static void main(String[] args) {
        play();
    }

    /**
     * This method is the main game method. It has a while loop to loop through the turns until somebody
     * hits 100 total score to win.
     */
    public static void play() {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        boolean playerTurn = true;
        int numberOne = 1;
        int opponentHold = 15;

        //Welcome player and get their name.
        System.out.println("Welcome to the dice game Pig." + "\n" + "Players take turns to roll a single dice as many times as they wish" + "\n" +
                "adding all roll results to a running total, but losing their gained score for the turn if they roll a 1.");
        System.out.print("Your opponent will be the computer, please enter your name > ");
        String playerName = scanner.nextLine();

        //Load and display previous game results
        loadResults(file);

        //Game loop
        while (playerScore < MAX_SCORE && computerScore < MAX_SCORE) {
            System.out.println(playerName + "'s Score: " + playerScore);
            System.out.println("Opponent Score: " + computerScore);

            if (playerTurn) {
                boolean validInput = false;
                System.out.println(playerName + "'s turn.");
                String input = null;
                while (!validInput) {
                    System.out.println("Roll or Hold? (r/h)");
                    input = scanner.nextLine();
                    if (input.equals("r") || input.equals("h")) {
                        validInput = true;
                    } else {
                        System.out.println("Invalid input. Please enter 'r' or 'h'.");
                    }
                }
                if (input.equals("r")) {
                    int roll = random.nextInt(6) + numberOne;
                    System.out.println("You rolled a " + roll);
                    if (roll == numberOne) {
                        System.out.println("Round over. You rolled a 1.");
                        roundScore = 0;
                        playerTurn = false;
                    } else {
                        roundScore += roll;
                        System.out.println("Round score: " + roundScore);
                    }
                } else if (input.equals("h")) {
                    playerScore += roundScore;
                    roundScore = 0;
                    playerTurn = false;
                }
            } else {
                System.out.println("");
                System.out.println("Computer's turn.");
                int roll = random.nextInt(6) + numberOne;
                System.out.println("Computer rolled a " + roll);
                System.out.println("Round Score: " + (roll + roundScore));
                if (roll == numberOne) {
                    System.out.println("Round over. Computer rolled a 1.");
                    roundScore = 0;
                    playerTurn = true;
                } else {
                    roundScore += roll;
                    if (roundScore >= opponentHold) {
                        computerScore += roundScore;
                        System.out.println("Computer holds. Round score: " + roundScore);
                        roundScore = 0;
                        playerTurn = true;
                    }
                }
            }
        }
        printResults(playerName);
        saveResults();
    }

    /**
     * This is a method that loads the previous game results and displays them for the user to see.
     *
     * @param file
     */
    public static void loadResults(File file) {
        //Load past game data from file
        int oldPlayerScore = 0, oldComputerScore = 0;

        if (file.exists()) {
            try {
                BufferedReader reader = new BufferedReader(new FileReader(file));
                String[] scores = reader.readLine().split(",");
                oldPlayerScore = Integer.parseInt(scores[0]);
                oldComputerScore = Integer.parseInt(scores[1]);
                reader.close();
            } catch (IOException e) {
                System.err.println("Error reading from file: " + e.getMessage());
            }
        }
        System.out.println("");
        System.out.println("Previous game scores!");
        System.out.println("Last Player Score: " + oldPlayerScore);
        System.out.println("Last Computer Score: "  + oldComputerScore);
        System.out.println("");
    }

    /**
     * This is a method to save the results to a file after the game is over.
     */
    public static void saveResults() {
        //Save game data to file
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.write(playerScore + "," + computerScore);
            writer.close();
        } catch (IOException e) {
            System.err.println("Error reading from file: " + e.getMessage());
        }

    }

    /**
     * This is a method to print the results to the screen after the game is over.
     *
     * @param playerName
     */
    public static void printResults(String playerName) {
        //Print game results
        if (playerScore >= MAX_SCORE) {
            System.out.println(playerName + " wins!");
            System.out.println("Score: " + playerScore);
        } else {
            System.out.println("Computer wins!");
            System.out.println("Score: " + computerScore);
        }
    }

    public static int getPlayerScore() {
        return playerScore;
    }
    public static int getRoundScore() {
        return roundScore;
    }
    public static int getComputerScore(){
        return computerScore;
    }

}
